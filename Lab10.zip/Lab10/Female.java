
import java.awt.*;
import java.applet.*;
import java.util.*; 


public class Female extends Robloxian
{
    public Female()
    {
    }
}
