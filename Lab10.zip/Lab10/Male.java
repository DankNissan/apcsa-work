
import java.awt.*;
import java.applet.*;
import java.util.*; 


public class Male extends Robloxian
{
    public Male()
    {
    }
}
